package com.duroos.yousef

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.webkit.*
import androidx.webkit.WebViewAssetLoader
import java.io.ByteArrayInputStream
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {
  private lateinit var web: WebView
  private val HOST = "appassets.androidplatform.net"

  override fun onCreate(b: Bundle?) {
    super.onCreate(b)
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
      requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    web = WebView(this); setContentView(web)
    Bridge.web = java.lang.ref.WeakReference(web)
    val loader = WebViewAssetLoader.Builder().setDomain(HOST)
      .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
    web.settings.apply {
      javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
      mediaPlaybackRequiresUserGesture = false; allowFileAccess = false
      mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
      setSupportMultipleWindows(true); javaScriptCanOpenWindowsAutomatically = true
    }
    CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
    web.addJavascriptInterface(Bridge(this), "Android")
    web.webChromeClient = object : WebChromeClient() {
      override fun onCreateWindow(v: WebView, d: Boolean, g: Boolean, m: Message): Boolean {
        val t = WebView(this@MainActivity)
        t.webViewClient = object : WebViewClient() {
          override fun shouldOverrideUrlLoading(w: WebView, r: WebResourceRequest): Boolean { openExt(r.url.toString()); return true }
          override fun onPageStarted(w: WebView, u: String?, f: android.graphics.Bitmap?) {
            if (u != null && u != "about:blank") { openExt(u); w.stopLoading() }
          }
        }
        (m.obj as WebView.WebViewTransport).webView = t; m.sendToTarget(); return true
      }
    }
    web.webViewClient = object : WebViewClient() {
      override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
        val u = r.url
        if (u.host == HOST) return false
        if (u.scheme == "intent" || u.scheme == "http" || u.scheme == "https" || u.scheme == "market") { openExt(u.toString()); return true }
        return false
      }
      override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? {
        if (r.url.host == HOST) return loader.shouldInterceptRequest(r.url)
        // طلبات fetch من التطبيق لمواقع تانية: ننفذها من الجهاز ونضيف CORS عشان الأحجام والتحميل يشتغلوا
        val h = r.requestHeaders
        if (h.keys.none { it.equals("Origin", true) } || !(r.url.scheme == "http" || r.url.scheme == "https")) return null
        return cors(r)
      }
    }
    web.loadUrl("https://$HOST/assets/index.html")
  }

  private fun cors(r: WebResourceRequest): WebResourceResponse? {
    val allow = mapOf("Access-Control-Allow-Origin" to "*", "Access-Control-Allow-Headers" to "*",
      "Access-Control-Allow-Methods" to "GET,HEAD,OPTIONS",
      "Access-Control-Expose-Headers" to "Content-Length, Content-Range, Content-Type, Accept-Ranges")
    if (r.method == "OPTIONS") return WebResourceResponse("text/plain", "utf-8", 204, "No Content", allow, ByteArrayInputStream(ByteArray(0)))
    return try {
      val c = URL(r.url.toString()).openConnection() as HttpURLConnection
      c.requestMethod = if (r.method == "HEAD") "HEAD" else "GET"
      c.connectTimeout = 15000; c.readTimeout = 30000; c.instanceFollowRedirects = true
      for ((k, v) in r.requestHeaders) if (!k.equals("Origin", true) && !k.equals("Referer", true) && !k.equals("Host", true) && !k.equals("Accept-Encoding", true)) c.setRequestProperty(k, v)
      val code = c.responseCode
      val hd = HashMap(allow)
      for (k in listOf("Content-Length", "Content-Range", "Accept-Ranges")) c.getHeaderField(k)?.let { hd[k] = it }
      val ct = (c.contentType ?: "application/octet-stream").substringBefore(";").trim()
      val enc = c.contentType?.substringAfter("charset=", "")?.takeIf { it.isNotEmpty() }
      val s = if (code >= 400) c.errorStream else c.inputStream
      WebResourceResponse(ct, enc, code, (c.responseMessage?.takeIf { it.isNotEmpty() } ?: "OK"), hd, s ?: ByteArrayInputStream(ByteArray(0)))
    } catch (e: Exception) { null }
  }

  fun openExt(u: String) {
    try {
      if (u.startsWith("intent:")) {
        val i = Intent.parseUri(u, Intent.URI_INTENT_SCHEME)
        try { startActivity(i) } catch (e: ActivityNotFoundException) {
          i.`package`?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$it"))) }
        }
      } else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u)))
    } catch (e: Exception) {}
  }

  @Deprecated("") override fun onBackPressed() { if (web.canGoBack()) web.goBack() else moveTaskToBack(true) }
  // مهم: ما بنعملش web.onPause() عشان الصوت يكمل في الخلفية
  override fun onDestroy() { Bridge.web = null; stopService(Intent(this, MediaService::class.java)); web.destroy(); super.onDestroy() }
}
