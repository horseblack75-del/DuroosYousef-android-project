package com.duroos.yousef

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaMetadata
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.IBinder
import android.os.PowerManager

class MediaService : Service() {
  companion object {
    @Volatile var inst: MediaService? = null
    @Volatile var title = ""; @Volatile var artist = ""; @Volatile var playing = false
    @Volatile var pos = 0L; @Volatile var dur = 0L
    const val CH = "duroos_media"
  }
  private lateinit var sess: MediaSession
  private var wl: PowerManager.WakeLock? = null

  override fun onCreate() {
    super.onCreate(); inst = this
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(NotificationChannel(CH, "تشغيل الدروس", NotificationManager.IMPORTANCE_LOW))
    sess = MediaSession(this, "duroos")
    sess.setCallback(object : MediaSession.Callback() {
      override fun onPlay() = Bridge.cmd("play")
      override fun onPause() = Bridge.cmd("pause")
      override fun onSkipToNext() = Bridge.cmd("next")
      override fun onSkipToPrevious() = Bridge.cmd("prev")
      override fun onSeekTo(p: Long) = Bridge.cmd("seek:$p")
    })
    sess.isActive = true
    wl = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "duroos:audio")
    update(true)
  }

  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    when (i?.action) { "toggle" -> Bridge.cmd("toggle"); "next" -> Bridge.cmd("next"); "prev" -> Bridge.cmd("prev") }
    refresh(); return START_NOT_STICKY
  }

  fun refresh() = update(false)

  private fun update(first: Boolean) {
    sess.setMetadata(MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title)
      .putString(MediaMetadata.METADATA_KEY_ARTIST, artist).putLong(MediaMetadata.METADATA_KEY_DURATION, dur).build())
    sess.setPlaybackState(PlaybackState.Builder().setActions(PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PAUSE or
      PlaybackState.ACTION_SKIP_TO_NEXT or PlaybackState.ACTION_SKIP_TO_PREVIOUS or PlaybackState.ACTION_SEEK_TO or PlaybackState.ACTION_PLAY_PAUSE)
      .setState(if (playing) PlaybackState.STATE_PLAYING else PlaybackState.STATE_PAUSED, pos, if (playing) 1f else 0f).build())
    try {
      if (playing) { if (wl?.isHeld == false) wl?.acquire(6 * 3600 * 1000L) } else if (wl?.isHeld == true) wl?.release()
    } catch (e: Exception) {}
    val n = build()
    if (first) { if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK) else startForeground(1, n) }
    else getSystemService(NotificationManager::class.java).notify(1, n)
  }

  private fun pi(a: String) = PendingIntent.getService(this, a.hashCode(), Intent(this, MediaService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
  private fun act(ic: Int, label: String, a: String) = Notification.Action.Builder(Icon.createWithResource(this, ic), label, pi(a)).build()

  private fun build(): Notification {
    val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
    return Notification.Builder(this, CH).setSmallIcon(R.drawable.ic_stat)
      .setContentTitle(title.ifEmpty { "دروس يوسف" }).setContentText(artist).setContentIntent(open)
      .setOngoing(playing).setVisibility(Notification.VISIBILITY_PUBLIC)
      .addAction(act(R.drawable.ic_prev, "السابق", "prev"))
      .addAction(act(if (playing) R.drawable.ic_pause else R.drawable.ic_play, "تشغيل/إيقاف", "toggle"))
      .addAction(act(R.drawable.ic_next, "التالي", "next"))
      .setStyle(Notification.MediaStyle().setMediaSession(sess.sessionToken).setShowActionsInCompactView(0, 1, 2)).build()
  }

  override fun onTaskRemoved(r: Intent?) { Bridge.cmd("pause"); stopSelf() }
  override fun onDestroy() { try { if (wl?.isHeld == true) wl?.release() } catch (e: Exception) {}; sess.release(); inst = null; super.onDestroy() }
  override fun onBind(i: Intent?): IBinder? = null
}
